%% bus_kafka.erl
-module(bus_kafka).
-behaviour(bus_beh).
-export([publish/2, subscribe/2, start_link/1]).