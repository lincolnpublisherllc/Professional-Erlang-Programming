%% dal_cache.erl
-module(dal_cache).
-export([start_link/1, get/1, put/2, invalidate/1]).
-define(TAB, dal_cache).