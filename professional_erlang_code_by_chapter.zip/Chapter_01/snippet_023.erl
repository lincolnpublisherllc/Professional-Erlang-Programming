%% apps/svc_obs/src/json_logger_h.erl
-module(json_logger_h).
-behaviour(logger_handler).
-export([log/2, config/1, filter_config/1]).