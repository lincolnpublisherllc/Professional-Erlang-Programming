%% pool_cpu.erl
-module(pool_cpu).
-behaviour(gen_server).
-export([start_link/1]).
-export([init/1, handle_info/2, terminate/2]).