%% ix_store.erl
-module(ix_store).
-export([start_link/1, put/2, get/1, range/2, snapshot/0, restore/0, compact/0]).