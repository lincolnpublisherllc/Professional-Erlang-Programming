Create diag_harness that can run a scenario and wrap measurements.
%% diag_harness.erl
-module(diag_harness).
-export([run/2, with_eprof/2, with_trace/2]).