%% File: api_guard.erl
-module(api_guard).
-export([parse_transform/2]).