%% apps/svc_core/src/feature.erl
-module(feature).
-export([enabled/1, get/2]).