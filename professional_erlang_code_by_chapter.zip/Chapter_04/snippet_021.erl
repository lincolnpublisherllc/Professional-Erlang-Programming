%% ix_seg_writer.erl
-module(ix_seg_writer).
-export([append/3]).