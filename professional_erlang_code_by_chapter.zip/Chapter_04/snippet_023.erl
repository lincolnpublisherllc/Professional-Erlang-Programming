%% ix_snapshot.erl
-module(ix_snapshot).
-export([write/1, restore/2]).