%% ix_indexer.erl
-module(ix_indexer).
-behaviour(gen_server).
-export([start_link/0, update/1, range/2]).
-export([init/1, handle_call/3, handle_cast/2]).