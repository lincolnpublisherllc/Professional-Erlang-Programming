%% perimeter.erl
-module(perimeter).
-export([gate/2]).  %% gate(Req, Ctx) -> {ok, Ctx1} | {deny, Code, Body}