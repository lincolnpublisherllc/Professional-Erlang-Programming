%% crc32.erl
-module(crc32).
-export([calc/1, init/0]).