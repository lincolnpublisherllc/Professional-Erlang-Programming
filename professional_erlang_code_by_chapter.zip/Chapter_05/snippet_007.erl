%% bus_beh.erl
-module(bus_beh).