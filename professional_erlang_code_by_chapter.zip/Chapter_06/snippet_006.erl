%% router_gs.erl
-module(router_gs).
-behaviour(gen_server).
-export([start_link/1, submit/4, cancel/1, stats/0]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2]).