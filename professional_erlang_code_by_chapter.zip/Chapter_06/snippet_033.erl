%% joiner.erl
-module(joiner).
-export([start_link/3]).