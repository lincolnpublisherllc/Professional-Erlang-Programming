%% ix_compact.erl
-module(ix_compact).
-export([run/2]).