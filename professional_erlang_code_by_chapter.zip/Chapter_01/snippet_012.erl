%% apps/svc_core/src/build_info.erl
-module(build_info).
-export([version/0, git_ref/0, built_at/0]).