%% store_beh.erl
-module(store_beh).