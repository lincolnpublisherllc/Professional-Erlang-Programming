%% crc32_port.erl
-module(crc32_port).
-export([start/0, calc/1]).
-define(TIMEOUT, 2000).