%% crc32_erlang.erl
-module(crc32_erlang).
-export([calc/1]).