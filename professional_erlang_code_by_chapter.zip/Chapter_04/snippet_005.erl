%% ix_store_gs.erl
-module(ix_store_gs).
-behaviour(gen_server).
-export([start_link/1, put/2, get/1, range/2, snapshot/0, restore/0, compact/0]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2]).