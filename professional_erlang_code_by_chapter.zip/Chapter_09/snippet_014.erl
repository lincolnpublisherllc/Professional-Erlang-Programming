%% diag_toggle.erl
-module(diag_toggle).
-export([enable/1, disable/0]).
-define(DEFAULT, 60_000).